package Libraries;

public class KeyWord {

	Keyword_CRM KC = new Keyword_CRM();

	// ------------------Keyword CRM -------------------//
	public String Siebel_Login() {
		return KC.Siebel_Login();
	}

	public String Siebel_Logout() {
		return KC.Siebel_Logout();
	}

	public String ContactCreation() {
		return KC.ContactCreation();
	}

	public String AccountCreation() {
		return KC.AccountCreation();
	}

	public String AddressCreation() {
		return KC.AddressCreation();
	}

	public String SwagLabs_Login() {
		return KC.SwagLabs_Login();
	}	

	public String SwagLabs_Logout() {
		return KC.SwagLabs_Logout();
	}
	
	public String SwagLabs_AddToCard() {
		return KC.SwagLabs_AddToCard();
	}
	
	public String SwagLabs_About() {
		return KC.SwagLabs_About();
	}
	
	public String SwagLabs_NavigateToLoginPage() {
		return KC.SwagLabs_NavigateToLoginPage();
	}
	
	
	

}
