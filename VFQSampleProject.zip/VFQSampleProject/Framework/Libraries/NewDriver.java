package Libraries;

import org.openqa.selenium.WebDriver;

public abstract interface NewDriver {
	public abstract WebDriver getNewDriver();
}